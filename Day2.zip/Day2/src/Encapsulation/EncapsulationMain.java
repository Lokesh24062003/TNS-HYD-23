package Encapsulation;

public class EncapsulationMain {

	public static void main(String[] args) {
		EncapsulationNormal n1 = new EncapsulationNormal();
		n1.setNoOfPalyers(11);
		n1.setIsQualified("True");
		n1.setTeamName("Warriors");
		
		
		n1.winner();
	}

}
