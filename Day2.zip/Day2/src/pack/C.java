package pack;

public class C {
	public void msg() {
		System.out.println("Hello!, from package 'pack' , class C");
	}
}
