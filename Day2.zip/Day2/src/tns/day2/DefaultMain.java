package tns.day2;

public class DefaultMain {

	public static void main(String[] args) {
		DefaultNormal d1 = new DefaultNormal();
		
		System.out.println(d1.str);

	}

}
