package tns.day2;

public class Approach1 {
	int a = 10;			// Instance Variable
	static int b = 20;	// Static Variable
	int display() {		// Instance Method
		return 30;
	}
	static void dispaly1() {	// Static Method
		System.out.println("This is Static Method");
	}
	public static void main(String[] args) {
		Approach1 app = new Approach1();	// Object Creation
		
		System.out.println(app.a);
		app.display();
		System.out.println(Approach1.b);
		Approach1.dispaly1();

	}

}
