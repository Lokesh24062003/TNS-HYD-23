package tns.day2;

public class PrivateAccessSpec {
	private String str = "This is a Private Member!";
	
	
// Getter & Setters are used to access the private members
//	Getter -> used to set the values
//	public String getStr() {
//		return str;
//	}
//
//	Setter -> used to get/retrieve the values
//	public void setStr(String str) {
//		this.str = str;
//	}


	public static void main(String[] args) {
		PrivateAccessSpec a1 = new PrivateAccessSpec();
		System.out.println(a1.str);
	}

}
