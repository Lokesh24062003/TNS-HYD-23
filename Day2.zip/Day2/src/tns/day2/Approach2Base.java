package tns.day2;

public class Approach2Base {
	int a = 10;
	static int b = 20;
	int display() {
		return 30;
	}
	static void display1() {
		System.out.println("This is Static Method");
	}
}
